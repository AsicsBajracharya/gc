const dates = [
  {
    date: 18,
    month: 5,
    eventTitle: "Virtual RoundTable on Transformative megatrends",
  },
  {
    date: 19,
    month: 5,
    eventTitle: "Virtual RoundTable on Transformative megatrends",
  },
  {
    date: 1,
    month: 5,
    eventTitle: "Virtual RoundTable on Transformative megatrends",
  },
  {
    date: 12,
    month: 5,
    eventTitle: "Virtual RoundTable on Transformative megatrends",
  },
  {
    date: 2,
    month: 5,
    eventTitle: "Virtual RoundTable on Transformative megatrends",
  },
  {
    date: 4,
    month: 5,
    eventTitle: "Virtual RoundTable on Transformative megatrends",
  },
  {
    date: 7,
    month: 5,
    eventTitle: "Virtual RoundTable on Transformative megatrends",
  },
];

module.exports = dates;
